<?php
class func {
    public static function checkLoginState($dbh)
    {
        // Start the session before any output is sent.
        if (!isset($_SESSION['id']) || !isset($_COOKIE['PHPSESSID'])) {
            session_start();
        }
        if (isset($_COOKIE['id']) && isset($_COOKIE['token']) && isset($_COOKIE['serial'])) {

            $query = "SELECT * FROM sessions WHERE sessions_userid=:userid AND sessions_token=:token AND sessions_serial=:serial"; // TODO: change to prepared statement.

            $userid = $_COOKIE['userid'];
            $token = $_COOKIE['token'];
            $serial = $_COOKIE['serial'];

            $stmt = $dbh->prepare($query);
            $stmt->execute(array(":userid" => $userid, ":token" => $token, ":serial" => $serial)); // Fixed the array syntax.

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row["sessions_userid"] > 0) {
                if (
                    $row["sessions_userid"] == $_COOKIE['userid'] &&
                    $row["sessions_token"] == $_COOKIE['token'] &&
                    $row["sessions_serial"] == $_COOKIE['serial']
                ) {
                    if (
                        $row["sessions_userid"] == $_SESSION['userid'] &&
                        $row["sessions_token"] == $_SESSION['token'] &&
                        $row["sessions_serial"] == $_SESSION['serial']
                    ) {
                        return true;
                    }
                }
            }
        }
    }
    public static function createRecord($dbh, $user_username, $user_id) {
        $query = "INSERT INTO `sessions`(`sessions_userid`, `sessions_token`, `sessions_serial`, `sessions_date`) VALUES (:userid, :token, :serial, :date)";
        $dbh->prepare('DELETE FROM sessions WHERE sessions_userid = :sessions_userid');

        $token = func::createString(32);
        $serial = func::createString(32);

        func::createCookie($user_username, $user_id, $token, $serial);
        func::createSession($user_username, $user_id, $token, $serial);

        $stmt = $dbh->prepare($query);
        $stmt->execute(array(':userid' => $user_id, ':token' => $token, ':serial' => $serial));
    }
    public static function createCookie($user_username, $user_id, $token, $serial) {
        setcookie('user_id', $user_id, time() + (86400) * 30);
        setcookie('user_username', $user_username, time() + (86400) * 30);
        setcookie('token', $token, time() + (86400) * 30);
        setcookie('serial', $serial, time() + (86400) * 30);
    }
    public static function createSession($user_username, $user_id, $token, $serial) {
        if (!isset($_SESSION['id'])|| !isset($_COOKIE['PHPSESSID'])) {
            session_start();
        }
        $_SESSION['user_username'] = $user_username;
        // setcookie('user_id', $user_id, time() + (86400) * 30, "/");
        // setcookie('token', $token, time() + (86400) * 30, "/");
        // setcookie('serial', $serial, time() + (86400) * 30, "/");
    }
    public static function createString($len) {
        $string="V4vCJsbzOyTQHcULR9h8DNokqMP2Zl6prnSmYd7s3ugXEF1IWi0A5fjKaGBeTwtxYz";
        $s = '';
        $r_new = '';
        $r_old = '';

        for ($i = 1; $i < $len; $i++) {
            while ($r_old == $r_new) {
                $r_new = rand(0, 60);
            }
            $r_old = $r_new;
            $s = $s.$string[$r_new];
        }
        return $s;
    }
}
?>
